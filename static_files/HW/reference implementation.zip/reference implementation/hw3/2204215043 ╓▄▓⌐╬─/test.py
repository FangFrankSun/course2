import numpy as np
import matplotlib.pyplot as plt
import pickle


def sigmoid(x):
    return 1 / (1 + np.exp(-x))


def L(x, A, B):
    B = B.reshape(A.shape[0], 1)
    Loss = 0
    for i in range(A.shape[0]):
        Loss += -np.log(sigmoid(B[i] * np.dot(A[i], x)))
    Loss = Loss / A.shape[0]
    return Loss


def dl(x, a, b):
    return -b * a * sigmoid(-b * np.dot(a, x))


def SGD(x, A, B, batchsize, step):
    curr_Loss = [L(x, A, B)]
    for k in range(0, 1000):
        batch = np.random.randint(0, A.shape[0], size=batchsize)
        dL = 0
        for i in batch:
            dL += dl(x, A[i], B[i])
        dL = dL / batchsize
        x = x - step * dL
        curr_Loss.append(L(x, A, B))
    return curr_Loss


if __name__ == '__main__':
    with open(r'C:\Users\86181\Desktop\data.txt', 'rb') as f:
        data = pickle.load(f)
    A = data[0].toarray()
    B = data[1]
    batchsize = 1
    step = 1e-2
    x = np.zeros((A.shape[1],))
    curr_Loss = SGD(x, A, B, batchsize, step)
    plt.figure()
    plt.plot(curr_Loss)
    plt.xlabel("The number of iterations")
    plt.ylabel("Logistic Regression curr_Loss")
    plt.title("SGD for Logistic Regression with fixed learning rate")
    plt.show()