import matplotlib.pyplot as plt
l1 = []
l2 = []
l3 = []
with open('losslist1.txt', "r") as f1:
    for line in f1.readlines():
        line = line.strip('\n')  # 去掉列表中每一个元素的换行符
        l1.append(float(line))
with open('losslist2.txt', "r") as f2:
    for line in f2.readlines():
        line = line.strip('\n')  # 去掉列表中每一个元素的换行符
        l2.append(float(line))
with open('losslist3.txt', "r") as f3:
    for line in f3.readlines():
        line = line.strip('\n')  # 去掉列表中每一个元素的换行符
        l3.append(float(line))
T = [i for i in range(100)]
plt.title('Logistic')
plt.xlabel('iterations')
plt.ylabel('loss values')
plt.plot(T, l1, '-',label='SGD_FLR')
plt.plot(T, l2, '--',label='SGD_DLR')
plt.plot(T, l3, '-.',label='SVRG')
plt.legend(loc='best')
plt.show()


