import numpy as np
def load(filename, d=124): # Read a file of the a9a dataset
    with open(filename, "r") as f:
        lines = f.readlines()
    N = len(lines)
    feature = np.zeros([N, d])
    label = np.zeros(N)
    for i, line in enumerate(lines):
        points = line.strip().split(" ")
        if points[0] == "+1":
            label[i] = 1
        else:
            label[i] = 0
        for point in points[1:]:
            feature[i][0] = 1 #添加X_0 = 1
            n = int(point.split(":")[0])
            feature[i][n] = 1
    return feature, label

def sigmoid(s):
    return 1.0 / (1.0 + np.exp(-s))
def predict(X,Y,W):
    #预测
    m, n = X.shape
    T = 0
    for i in range(m):
        s = X[i].dot(W)
        if sigmoid(s) >= 0.5:
            pre = 1
        else:
            pre = 0

        #统计正确数
        if pre == Y[i]:
           T += 1
    return T/m

def SVRG(X , Y, lr, depth, W):
    m, n = X.shape
    loss_list = []#存每一步的损失函数
    #SGD_FLR
    for k in range(5):
      W_k = W
      dW_2 = np.ones([n]).reshape((-1 , 1))
      for l in range(m):
          dW_2 += X[l:l+1].T*(sigmoid(X[l:l+1].dot(W_k)) - Y[l:l+1])
      mu = dW_2/m

      for i in range(depth):
        S = np.matmul(X, W)
        H = sigmoid(S)
        #损失函数 loss
        loss =  []
        for j in range(m):
          loss.append(-np.log(H[j]) * Y[j] - (1 - Y[j]) * np.log(1 - H[j]))
        loss = np.sum(loss) / m
        loss_list.append(loss)
        print(loss)
        # 梯度下降函数更新W权重
        index = np.random.randint(m)
        x = X[index:index + 1]
        y = Y[index:index + 1]
        dW_0 = x.T*(sigmoid(x.dot(W)) - y)
        dW_1 = x.T*(sigmoid(x.dot(W_k)) - y)
        W += -lr * (dW_0-dW_1+mu)
        lr *= 0.99
    return W, loss_list
if __name__ == "__main__":
    X, Y = load("a9a.txt") #训练集
    X_t, Y_t = load("a9a.t.txt") #测试集
    X = np.array(X)
    Y = np.array(Y)
    W = np.ones([124]).reshape((-1 , 1)) #初始化 W
    depth = 20
    lr = 0.1
    W_best, loss_list = SVRG(X, Y, lr, depth, W)
    print('SVRG预测正确率:{:.2%}'.format(predict(X_t, Y_t, W_best)))

    with open("losslist3.txt", "w") as f:
        for i in range(100):
              f.write(str(loss_list[i])+'\n')

