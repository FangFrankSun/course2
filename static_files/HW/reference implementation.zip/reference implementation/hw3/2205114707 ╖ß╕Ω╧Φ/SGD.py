import numpy as np
import random


def ju(x):
    if x > 0:
        return 1
    else:
        return -1


def SGD_fixedstep(x, y, step=0.01, t=1e6):  # y为1，-1
    x = np.append(x, np.ones([x.shape[0], 1]), axis=1)
    para = np.ones(x.shape[1])  # 123列（0-123）为标签参数, 124为常数
    for ti in range(0, int(t)):
        randm = random.randint(0, x.shape[0] - 1)
        g = np.dot(x[randm, :], para)
        t0 = np.exp(-y[randm] * g)
        nabla = -1.0 * (y[randm] * t0) / (1 + t0) * x[randm, :]
        para -= step * nabla
    return para


def SGD_decstep(x, y, l=200, r=2e5, t=1e6):  # y为1，-1
    x = np.append(x, np.ones([x.shape[0], 1]), axis=1)
    para = np.ones(x.shape[1])  # 123列（0-123）为标签参数, 124为常数
    for ti in range(0, int(t)):
        step = l / (r + ti)
        randm = random.randint(0, x.shape[0] - 1)
        g = np.dot(x[randm, :], para)
        t0 = np.exp(-y[randm] * g)
        nabla = -1.0 * (y[randm] * t0) / (1 + t0) * x[randm, :]
        para -= step * nabla
    return para


def SVRG(x, y, step=0.01, t=1e5):
    x = np.append(x, np.ones([x.shape[0], 1]), axis=1)
    para = np.ones(x.shape[1])  # 123列（0-123）为标签参数, 124为常数
    nabla0, nabla_sum = nabla_all(x, y, para)
    for ti in range(0, int(t)):
        if ti % 501 == 0:  # 500次更新一次, 计算速度太慢
            nabla0, nabla_sum = nabla_all(x, y, para)
        randm = random.randint(0, x.shape[0] - 1)
        g = np.dot(x[randm, :], para)
        t0 = np.exp(-y[randm] * g)
        nabla = -1.0 * (y[randm] * t0) / (1 + t0) * x[randm, :]
        para -= step * (nabla - nabla0[randm, :]+nabla_sum)
    return para


def nabla_all(x, y, para):
    nabla = np.zeros(x.shape)
    g = np.dot(x, para)
    t0 = np.exp(-1 * g)
    a = np.multiply(y, t0)
    temp = -1.0 * np.multiply(y, t0) / (1 + t0)
    for i in range(0, nabla.shape[0]):
        nabla[i, :] = x[i, :] * temp[i]
    nabla_sum = sum(nabla) / nabla.shape[0]
    return nabla, nabla_sum


def testfunc(x, y, para):  # 计算准确率
    n = x.shape[0]
    cnt = 0
    x = np.append(x, np.ones([x.shape[0], 1]), axis=1)
    for i in range(0, n):
        g = np.dot(x[i, :], para)
        if y[i] == ju(g):  # >0为1，<0为-1
            cnt += 1
    return cnt / n


# 第一列（0）为y，之后123列（1-124）为标签
data = np.loadtxt("data.txt")
test = np.loadtxt("test.txt")
para = SGD_fixedstep(data[:, 1:], data[:, 0])
testrate = testfunc(test[:, 1:], test[:, 0], para)
print("固定步长法：\n训练集准确率：", testfunc(data[:, 1:], data[:, 0], para))
print("测试集准确率：", testfunc(test[:, 1:], test[:, 0], para))
para2 = SGD_decstep(data[:, 1:], data[:, 0])
testrate2 = testfunc(test[:, 1:], test[:, 0], para2)
print("减小步长法：\n训练集准确率：", testfunc(data[:, 1:], data[:, 0], para2))
print("测试集准确率：", testfunc(test[:, 1:], test[:, 0], para2))
para = SVRG(data[:, 1:], data[:, 0])
print("SVRG\n训练集准确率：", testfunc(data[:, 1:], data[:, 0], para))
print("测试集准确率：", testfunc(test[:, 1:], test[:, 0], para))
