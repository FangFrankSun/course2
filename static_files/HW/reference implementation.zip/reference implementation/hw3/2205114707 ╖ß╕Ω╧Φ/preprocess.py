import numpy as np
import pandas as pd

data = pd.read_csv("a9a.txt", delimiter='\s|:', header=None)
test = pd.read_csv("a9atest.txt", delimiter='\s|:', header=None)
y = np.array(data.loc[:, 0])
x = np.zeros([data.shape[0], 124], dtype=int)
for i, temp in data.iterrows():
    for j, t in temp.iteritems():
        if j % 2 == 1 and np.isnan(t) == 0:
            x[i, int(t)] = 1
print(y.shape)
x[:, 0] = y
y2 = np.array(test.loc[:, 0])
x2 = np.zeros([test.shape[0], 124], dtype=int)
for i, temp in test.iterrows():
    for j, t in temp.iteritems():
        if j % 2 == 1 and np.isnan(t) == 0:
            x2[i, int(t)] = 1
x2[:, 0] = y2
np.savetxt('data.txt', x, fmt='%d')  # x从1开始 y为0列
np.savetxt('test.txt', x2, fmt='%d')
