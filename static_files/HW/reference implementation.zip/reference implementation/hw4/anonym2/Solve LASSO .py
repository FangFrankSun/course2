#!/usr/bin/env python
# coding: utf-8

import random
import matplotlib.pyplot as plt
import numpy as np
import time
plt.rcParams['font.sans-serif']=['SimHei']       
plt.rcParams['axes.unicode_minus']=False
def shrink(z, t): #软阈值函数
    x = np.zeros(z.shape)
    x[z>t] = z[z>t]-t
    x[z<-t] = z[z<-t]+t
    return x
def ObjValue(A,x,z,b,lam): #求LASSO的函数值
    LS_norm2=np.linalg.norm(A@x-b,ord=2)
    z_norm1=np.linalg.norm(z,ord=1)
    return 1/2*LS_norm2+lam*z_norm1
def rho(A): #求矩阵A的最大特征值
    eig, _ = np.linalg.eig(A.T @ A)
    return np.max(eig)
def bt(A,x,b,j): #求BCD中的bt
    summ=np.zeros((500,1))
    for i in range(j):#求下标小于当前更新下标的xA之和
        rs=x[i][0]*A[:,i].reshape(500,-1)#将xA转成500*1的列向量，防止计算时报错
        summ=summ+rs
    for i in range(j+1,len(x)):#求下标大于当前更新的下标的Ax之和
        rs=x[i][0]*A[:,i].reshape(500,-1)
        summ=summ+rs
    bt=b-summ
    return bt
def Display(objlist,t):#展示迭代过程与结果的函数
    plt.scatter([k for k in range(len(objlist))],objlist, s=5,                c='b', edgecolors = 'r', linewidth=0.5, alpha = 0.3)
    plt.grid()
    plt.show()
    print("Final Result：",objlist[-1],'Time Spending:',t)
    
def ProxDecent(A,x,b,lam,t): #临近点梯度下降算法
    err = 1 #初始化误差
    k=0    #迭代次数
    objlist=[ObjValue(A,x,x,b,lam)]
    time_start = time.time()
    while err > 1e-8:#停机条件，误差小于1e-8
        z = x - t *(A.T @ A @ x - A.T @ b) #先对x做梯度下降，记为z
        x = shrink(z, t*lam) 
        #通过软阈值函数对z进行拉回，求得临近点算子更新x        
        objlist.append(ObjValue(A,x,x,b,lam))
        err=np.abs(objlist[-1]-objlist[-2]) #以前后两次目标函数值之差作为误差
        if k>2000: #迭代上限2000次
            break
    time_end = time.time()   
    plt.title('Proximal Gradient Descent with lam='+str(lam))
    Display(objlist,time_end-time_start)
    return objlist[-1],time_end-time_start
 
def BCD(A,x,b,lam):
    err=1
    k=0
    y=np.ones([100, 1])
    x[:5, 0] += np.array([i+1 for i in range(5)]) # x_denotes expected x
    objlist=[ObjValue(A,x,x,b,lam)]
    time_start = time.time()
    while err>1e-8: #停机条件，三个算法均做相同指定
        k+=1
        for i in range(len(x)):#按照规则，依次更新x的各分量
            if x[i][0]>0:                
                x[i][0]=1/(A[:,i].T@A[:,i])*(A[:,i].T@bt(A,x,b,i)-lam)
            elif x[i][0]<0:
                x[i][0]=1/(A[:,i].T@A[:,i])*(A[:,i].T@bt(A,x,b,i)+lam)
            elif abs(A[:,i].T@bt(A,x,b,i))<=lam:
                x[i][0]=0        
        objlist.append(ObjValue(A,x,x,b,lam))
        err=np.abs(objlist[-1]-objlist[-2])
        if k>2000: #迭代上限2000次
            break
    time_end = time.time()
    plt.title('BCD with lam='+str(lam))
    Display(objlist,time_end-time_start)
    return objlist[-1],time_end-time_start

def ADMM(A,x,b,lam,rho):
    err=1
    u= np.ones([100, 1])
    rho_i=np.identity(A.shape[1])*rho #将rho值赋给100*100的矩阵，用于计算
    z=x #ADMM思想，z=x
    k=0
    objlist=[ObjValue(A,x,z,b,lam)]
    time_start=time.time()
    while err > 1e-8:
        #按照规则，依次更新算子x，z，u
        x=np.linalg.inv(A.T@A+rho_i)@(A.T@b+rho*(z-u))
        z=shrink(x+u,lam/rho)
        u=u+x-z
        k+=1
        if k>2000:
            break
        objlist.append(ObjValue(A,x,z,b,lam))
        err=np.abs(objlist[-1]-objlist[-2])
    time_end=time.time()
    plt.title('ADMM with lam='+str(lam))
    Display(objlist,time_end-time_start)
    return objlist[-1],time_end-time_start
if __name__ == '__main__':
    np.random.seed(2021) 
    A = np.random.rand(500, 100)#给问题参数A,b,lam
    x = np.zeros([100, 1])
    x[:5, 0] += np.array([i+1 for i in range(5)])
    b = np.matmul(A, x) + np.random.randn(500, 1) * 0.1   
    lams= [0.1,1,10] #正则参数的不同取值
    rho = rho(A)#求ADMM中二次罚项的系数，为A的最大特征值
    t=1/rho  # 近端梯度下降迭代过程中用到的步长t，的倒数 
    
    PDresults=[]#初始化存储算法结果与运行时间的列表
    PDtimes=[]
    BCDresults=[]
    BCDtimes=[]
    ADMMresults=[]
    ADMMtimes=[]
    
    plt.figure(figsize=(10,10))
    for lam in lams: 
        x = np.zeros([100, 1])
        x[:5, 0] += np.array([i+1 for i in range(5)]) 
        result,stime=ProxDecent(A,x,b,lam,t)
        PDresults.append(result)
        PDtimes.append(str(stime)+'s')      
    plt.figure(figsize=(10,10))
    for lam in lams: 
        x = np.zeros([100, 1])
        x[:5, 0] += np.array([i+1 for i in range(5)]) 
        result,stime=BCD(A,x,b,lam)
        BCDresults.append(result)
        BCDtimes.append(str(stime)+'s')       
    for lam in lams: 
        x = np.zeros([100, 1])
        x[:5, 0] += np.array([i+1 for i in range(5)])
        result,stime=ADMM(A,x,b,lam,rho)
        ADMMresults.append(result)
        ADMMtimes.append(str(stime)+'s') 
        
    for i in range(3):#输出结果，将三类算法进行收敛性与收敛速度的比较
        print('\n')
        print('When regularization parameter = '+str(lams[i])+':')
        print('The final resuls: ')
        print('Proximal Gradient Descent:',PDresults[i])
        print('BCD:',BCDresults[i])
        print('ADMM:',ADMMresults[i])
        print('Time spending: ')
        print('Proximal Gradient Descent:',PDtimes[i])
        print('BCD:',BCDtimes[i])
        print('ADMM:',ADMMtimes[i])


# In[ ]:




