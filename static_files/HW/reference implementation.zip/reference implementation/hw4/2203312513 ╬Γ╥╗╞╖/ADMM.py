class ADMM:
    def __init__(self, A, b, lam, x_=None):
        self.__A = A
        self.__b = b
        self.__lam = lam
        self.__rho = 0
        self.__x_ = x_
        self.__x = np.zeros([A.shape[1], 1])
        self.__z = np.zeros([A.shape[1], 1])
        self.__u = np.zeros([A.shape[1], 1])
        self.value = []

    def solve(self):
        step = 0
        f = self.func()
        f_ = self.func(method='except')
        while np.linalg.norm(f_ - f) > 0.01:
            step += 1
            self.__rho = step + 1000
            self.__x = self.x_update()
            self.__z = self.z_update()
            self.__u = self.u_update()
            f = self.func()
            self.value.append(f)
        print(self.value[-1])
        self.draw()

    def u_update(self):
        return self.__u + self.__x - self.__z

    def z_update(self):
        z = self.__x + self.__u
        x = np.sign(z) * np.maximum(np.abs(z) - self.__lam / self.__rho, 0)
        return x

    def x_update(self):
        n = self.__x.shape[0]
        temp1 = np.linalg.inv(self.__A.T @ self.__A + self.__rho * np.identity(n))
        temp2 = self.__A.T @ self.__b + self.__rho * (self.__z - self.__u)
        return np.matmul(temp1, temp2)

    def func(self, method='train'):
        if method == 'except':
            x = self.__x_
            z = self.__x_
        else:
            x = self.__x
            z = self.__z
        return 0.5 * (np.linalg.norm(self.__A @ x - self.__b, ord=2) ** 2) + self.__lam * np.linalg.norm(z, ord=1)

    def draw(self):
        plt.figure()
        plt.plot(range(len(self.value)), self.value)
        plt.title('LASSO: ADMM')
        plt.xlabel('Steps')
        plt.ylabel('Value')
        plt.show()

if __name__ == '__main__':
    ADMM(A, b, lam, x_).solve()