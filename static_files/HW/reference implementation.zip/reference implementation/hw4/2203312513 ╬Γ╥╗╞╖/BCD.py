class BCD:
    def __init__(self, A, b, lam, x_=None):
        self.__A = A
        self.__b = b
        self.__lam = lam
        self.__x_ = x_
        self.__x = np.zeros([A.shape[1], 1])
        self.value = []

    def solve(self):
        step = 0
        K = self.__x.shape[0]
        f = self.func()
        f_ = self.func(method='except')
        while np.linalg.norm(f_ - f) > 0.1:
            for k in range(K):
                step += 1
                self.__x[k] = self.x_update(k)
                f = self.func()
                self.value.append(f)
        self.draw()
        print(f_)
        print(self.value[-1])

    def x_update(self, k):
        A_k = self.__A[:, k].reshape(self.__A.shape[0], 1)
        b_t = self.b_t(k)
        Ab = A_k.T @ b_t
        AAI = np.linalg.inv(A_k.T @ A_k)
        return AAI @ np.sign(Ab) * np.maximum(np.abs(Ab) - self.__lam, 0)

    def b_t(self, k):
        A_k = self.__A[:, k].reshape(self.__A.shape[0], 1)
        x_k = self.__x[k].reshape(1, 1)
        b = self.__b - np.matmul(self.__A, self.__x) + np.matmul(A_k, x_k)
        return b

    def func(self, method='train'):
        if method == 'except':
            x = self.__x_
        else:
            x = self.__x
        return 0.5 * (np.linalg.norm(self.__A @ x - self.__b, ord=2) ** 2) + self.__lam * np.linalg.norm(x, ord=1)

    def draw(self):
        plt.figure()
        plt.plot(range(len(self.value)), self.value)
        plt.title('LASSO: BCD')
        plt.xlabel('Steps')
        plt.ylabel('Value')
        plt.show()

if __name__ == '__main__':
    BCD(A, b, lam, x_).solve()