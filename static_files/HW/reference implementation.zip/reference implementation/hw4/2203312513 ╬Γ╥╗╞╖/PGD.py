class ProximalGD:
    def __init__(self, A, b, lam, x_=None):
        self.__A = A
        self.__b = b
        self.__lam = lam
        self.__s = 0
        self.__x_ = x_
        self.__x = np.zeros([A.shape[1], 1])
        self.value = []

    def solve(self):
        f = self.func()
        f_ = self.func(method='except')
        step = 0
        while np.linalg.norm(f_ - f) > 0.01:
            step += 1
            self.__s = 0.1/(1000+step)
            z = self.__x - self.__s * self.grad()
            self.__x = self.prox(z)
            f = self.func()
            self.value.append(f)
        self.draw()
        print(self.value[-1])

    def func(self, method='train'):
        if method == 'except':
            x = self.__x_
        else:
            x = self.__x
        return 0.5 * np.linalg.norm(self.__A @ x - self.__b) ** 2 + self.__lam * np.linalg.norm(x, ord=1)

    def grad(self):
        return self.__A.T @ (self.__A @ self.__x - self.__b)

    def prox(self, z):
        x = np.sign(z) * np.maximum(np.abs(z)-self.__lam * self.__s, 0)
        return x

    def draw(self):
        plt.figure()
        plt.plot(range(len(self.value)), self.value)
        plt.title('LASSO: Proximal Gradient Descent')
        plt.xlabel('Steps')
        plt.ylabel('Value')
        plt.show()


if __name__ == '__main__':
    ProximalGD(A, b, lam, x_).solve()
