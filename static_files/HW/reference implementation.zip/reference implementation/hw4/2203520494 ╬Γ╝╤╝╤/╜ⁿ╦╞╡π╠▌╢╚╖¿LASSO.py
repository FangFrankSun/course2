#!/usr/bin/env python
# coding: utf-8

# In[100]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
import math
from sklearn.preprocessing import StandardScaler 
mpl.rcParams[u'font.sans-serif']=['simhei']
mpl.rcParams['axes.unicode_minus']=False


# In[128]:


np.random.seed(2021)
A=np.random.rand(500,100)
x_=np.zeros([100,1])
x_[:5,0]+=np.array([i+1 for i in range(5)]) 
b=np.matmul(A,x_)+np.random.randn(500,1)*0.1  #add a noise to b
lam=0.1


# In[129]:


#定义目标函数
def objectiveF(A,x,b,lam):
    temp=np.matmul(A,x)-b
    obj=1/2*np.matmul(temp.T,temp)+lam*np.linalg.norm(x,ord=1)
    return float(obj)


# In[130]:


obj_=objectiveF(A,x_,b,lam) #最优值
w,v=np.linalg.eig(np.matmul(A.T,A))
beta=max(w)  #梯度利普希兹常数
s=1/beta    #g固定步长
m,n=A.shape
x=np.random.rand(100,1)   #初始化x0
set_obj_judge=[]
obj=objectiveF(A,x,b,lam)
set_obj_judge.append((obj-obj_)/obj_)  #(f-f*)/f*
steps=[0]
for k in range(1,5000):   #设置最大迭代次数
    grad_f=np.matmul(A.T,np.matmul(A,x)-b)
    z=x-s*grad_f
    x=np.sign(z)*np.maximum(np.abs(z)-lam/beta,0)  #更新x
    obj=objectiveF(A,x,b,lam)
    set_obj_judge.append((obj-obj_)/obj_)
    steps.append(k)
    if set_obj_judge[-1]<=1e-7:  #停机条件 (f-f*)/f*<=1e-7
        break
#print(x)


# In[135]:


#画图
p=plt.figure(figsize=(12,6))
ax1=p.add_subplot(1,2,1)
plt.plot(steps[-500:],set_obj_judge[-500:])
plt.xlabel("steps  ( lambda=0.1 )");plt.ylabel("(f-f*)/f*")
plt.show() 
print("    迭代步数为：",k);
print("    最终目标函数取值：",obj)
print("    期望目标函数取值：",objectiveF(A,x_,b,lam))

