#!/usr/bin/env python
# coding: utf-8

# In[17]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
import math
from sklearn.preprocessing import StandardScaler 
mpl.rcParams[u'font.sans-serif']=['simhei']
mpl.rcParams['axes.unicode_minus']=False


# In[42]:


np.random.seed(2021)
A=np.random.rand(500,100)
x_=np.zeros([100,1])
x_[:5,0]+=np.array([i+1 for i in range(5)]) 
b=np.matmul(A,x_)+np.random.randn(500,1)*0.1  #add a noise to b
lam=0.1
m,n=A.shape
w,v=np.linalg.eig(np.matmul(A.T,A))
beta=max(w)  #梯度利普希兹常数


# In[43]:


#定义目标函数
def objectiveF(A,x,b,lam):
    temp=np.matmul(A,x)-b
    obj=1/2*(np.linalg.norm(temp))**2+lam*np.linalg.norm(x,ord=1)
    return float(obj)
obj_=objectiveF(A,x_,b,lam) #最优值


# In[52]:


# ADMM for LASSO
rho=beta
x=np.zeros([n,1])  #初始化x0,z0,u0
z=np.zeros([n,1])
u=np.zeros([n,1])
obj=objectiveF(A,x,b,lam)
set_obj=[obj]
steps=[0]
for t in range(1,15000):
    temp1=np.linalg.inv((np.matmul(A.T,A)+rho*np.eye(n)))
    temp2=np.matmul(A.T,b)+rho*(z-u)
    x=np.matmul(temp1,temp2)  #更新得到x(t+1)
    z1=z              #记录zt
    z=np.sign(x+u)*np.maximum(np.abs(x+u)-lam/rho,0) #更新得到z（t+1）
    u=u+x-z          #更新得到u(t+1)
    S=rho*(z-z1)     # dual residual
    R=x-z            #primal residual
    steps.append(t)
    obj=objectiveF(A,x,b,lam)
    set_obj.append(obj)
    if np.linalg.norm(S)<1e-6 and np.linalg.norm(R)<1e-6:    #停止准则
        break
#print(x)


# In[53]:


#画图
p=plt.figure(figsize=(6,6))
plt.plot(steps,set_obj)
plt.xlabel("steps  ( lambda=0.1 )")
plt.ylabel("f")
plt.show() 
print("    迭代步数为：",steps[-1])
print("    最终目标函数取值：",obj)
print("    期望目标函数取值：",objectiveF(A,x_,b,lam))

