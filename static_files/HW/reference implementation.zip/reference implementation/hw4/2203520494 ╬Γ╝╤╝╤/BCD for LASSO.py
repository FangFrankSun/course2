#!/usr/bin/env python
# coding: utf-8

# In[58]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
import math
from sklearn.preprocessing import StandardScaler 
mpl.rcParams[u'font.sans-serif']=['simhei']
mpl.rcParams['axes.unicode_minus']=False


# In[139]:


np.random.seed(2021)
A=np.random.rand(500,100)
x_=np.zeros([100,1])
x_[:5,0]+=np.array([i+1 for i in range(5)]) 
b=np.matmul(A,x_)+np.random.randn(500,1)*0.1  #add a noise to b
lam=0.1
m,n=A.shape


# In[140]:


#定义目标函数
def objectiveF(A,x,b,lam):
    temp=np.matmul(A,x)-b
    obj=1/2*(np.linalg.norm(temp))**2+lam*np.linalg.norm(x,ord=1)
    return float(obj)
#定义求bt的函数
def update_b(A,x,b,k):
    temp=A[:,k].reshape(m,1)
    u_b=b-np.matmul(A,x)+x[k,0]*temp
    return u_b
obj_=objectiveF(A,x_,b,lam) #最优值


# In[145]:


# BCD for LASSO
x=np.zeros([100,1])  #初始化x0
set_obj_judge=[]
obj=objectiveF(A,x,b,lam)
set_obj_judge.append((obj-obj_)/obj_)  #(f-f*)/f*
steps=[0]
for t in range(1,1000):    #设置最大迭代轮数
    for k in range(n):    #更新x的各个分量
        bt=update_b(A,x,b,k)   
        temp=float(np.matmul(A[:,k].T,bt))  #Ai bt  这样子可以减少计算量
        norm2=np.matmul(A[:,k].T,A[:,k])  #Ai2
        if temp>lam:
            x[k,0]=(temp-lam)/norm2
        elif temp<(-lam):
            x[k,0]=(temp+lam)/norm2
        else:
            x[k,0]=0
    steps.append(t)
    obj=objectiveF(A,x,b,lam)
    set_obj_judge.append((obj-obj_)/obj_)
    if set_obj_judge[-1]<=1e-5:  #停机条件 (f-f*)/f*<=1e-5
        break
#print(x)


# In[146]:


#画图
p=plt.figure(figsize=(6,6))
plt.plot(steps,set_obj_judge)
plt.xlabel("steps  ( lambda=1 )")
plt.ylabel("(f-f*)/f*")
plt.show() 
print("    迭代步数为：",steps[-1])
print("    最终目标函数取值：",obj)
print("    期望目标函数取值：",objectiveF(A,x_,b,lam))

