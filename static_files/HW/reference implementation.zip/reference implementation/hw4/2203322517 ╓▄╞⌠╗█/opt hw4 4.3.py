import numpy as np
import matplotlib.pyplot as plt
np.random.seed(2022) # set a constant seed to get same random matrix
A = np.random.rand(500, 100)
x_ = np.zeros([100, 1])
x_[:5, 0] += np.array([i+1 for i in range(5)]) # x_denotes expected x
b = np.matmul(A, x_) + np.random.randn(500, 1) * 0.1 #add a noise to b
lam = 10 # try some different values in {0.1, 1, 10}

#ADMM Algorithm
def fxz(A,x,z,b,lam):
    f=1/2*np.linalg.norm(A@x-b,ord=2)**2+lam*np.linalg.norm(z,ord=1)
    return f
def Beta(A):
    return max(np.linalg.eig(A.T@A)[0])
def xp(z,lam,A):
    temp=abs(z)-lam/Beta(A)
    for i in range(len(temp)):
        if temp[i]>0:
            temp[i]=temp[i]
        else:
            temp[i]=0
    xp=np.sign(z)*temp
    return xp
def ADMM(A,x,b,lam):
    mu= np.ones([100, 1])
    rho = Beta(A)
    rho_i=np.identity(A.shape[1])*rho
    z=x
    k=0
    F=[]
    f=fxz(A,x,z,b,lam)
    while k<100:
        x=np.linalg.inv(A.T@A+rho_i)@(A.T@b+rho*(z-mu))
        z=xp(x+mu,lam,A)
        mu=mu+x-z
        k=k+1
        deltaf=(f-fxz(A,x,z,b,lam))/fxz(A,x,z,b,lam)
        f=fxz(A,x,z,b,lam)
        F.append(f)
    plt.plot(list(range(0,100)), F)
    plt.show()
    print("lam为：",lam,"时结果为：",fxz(A,x,z,b,lam))


ADMM(A,x_,b,10)
ADMM(A,x_,b,1)
ADMM(A,x_,b,0.1)