import numpy as np
import matplotlib.pyplot as plt
np.random.seed(2022) # set a constant seed to get same random matrix
A = np.random.rand(500, 100)
x_ = np.zeros([100, 1])
x_[:5, 0] += np.array([i+1 for i in range(5)]) # x_denotes expected x
b = np.matmul(A, x_) + np.random.randn(500, 1) * 0.1 #add a noise to b
lam = 10 # try some different values in {0.1, 1, 10}

#PGD Algrithm
def fx(A,x,b,lam):#计算函数值
    f=1/2*np.linalg.norm(A@x-b,ord=2)**2+lam*np.linalg.norm(x,ord=1)
    return f
def Beta(A):#计算f的beta值
    return max(np.linalg.eig(A.T@A)[0])
def z(A,x,b):
    beta=Beta(A)
    z=(np.eye(len(x))-A.T@A/beta)@x+A.T@b/beta
    return z
def xp(z,lam,A):#临近点算子
    temp=abs(z)-lam/Beta(A)
    for i in range(len(temp)):
        if temp[i]>0:
            temp[i]=temp[i]
        else:
            temp[i]=0
    xp=np.sign(z)*temp
    return xp
def prox(A,x,b,lam,ml):#近端梯度下降算法
    k=0
    fmin=fx(A,x,b,lam)
    fk=fmin
    f_list=[fk]
    while k<ml:
        k=k+1
        x=xp(z(A,x,b),lam,A)
        fk=fx(A,x,b,lam)
        f_list.append(fk)
        if fk<fmin:
            fmin=fk
    plt.plot(list(range(len(f_list))),f_list)
    plt.show()
    print("lam为：",lam,"时结果为：",fmin)

prox(A,x_,b,10,1000)
prox(A,x_,b,1,1000)
prox(A,x_,b,0.1,1000)