import numpy as np
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
np.random.seed(2021) # set a constant seed to get same random matrixs
A = np.random.rand(500, 100)
x_ = np.zeros([100, 1])
x_[:5, 0] += np.array([i+1 for i in range(5)]) # x_denotes expected x
b = np.matmul(A, x_) + np.random.randn(500, 1) * 0.1 #add a noise to b
lam = 10 # try some different values in {0.1, 1, 10}
def lasso(A,x,b,lam):#lasso的函数值
    f=1/2*np.linalg.norm(np.dot(A,x)-b,ord=2)**2+lam*np.linalg.norm(x,ord=1)
    return f
def gradient(A,x,b,t):
    z=np.dot((np.eye(len(x))-t*np.dot(A.T,A)),x)+t*np.dot(A.T,b)
    return z    
def prox(z,lam,t):#临近点算子
    temp=abs(z).copy()-lam*t
    for i in range(len(temp)):
        if temp[i]<0:
            temp[i]=0
    proxvalue=np.sign(z)*temp
    return proxvalue
def p(f_list,lam,fmin,kmin):
    plt.title('PGD算法迭代图像')
    plt.plot(list(range(len(f_list))), f_list, color='blue', label='t=0.0001,lam='+lam)
    plt.legend()
    plt.xlabel('step')
    plt.ylabel('function value')
    plt.show()
    print("最终迭代结果为：",fmin)
    print("对应的迭代步数为：",kmin)    
def ProxGD(A,x,b,lam,ml):
    t=0.0001
    k=0
    kmin=0
    fmin=lasso(A,x,b,lam)
    fk=fmin
    f_list=[fk]
    while k<ml:
        k=k+1
        x=prox(gradient(A,x,b,t),lam,t)
        fk=lasso(A,x,b,lam)
        f_list.append(fk)
        if fk<fmin:
            fmin=fk
            kmin=k
    p(f_list,str(lam),fmin,kmin)
#ProxGD(A,x_,b,10,1000)
#ProxGD(A,x_,b,1,1000)
ProxGD(A,x_,b,0.1,1000)