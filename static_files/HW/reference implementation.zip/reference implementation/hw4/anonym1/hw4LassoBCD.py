import numpy as np
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
np.random.seed(2021) # set a constant seed to get same random matrixs
A = np.random.rand(500, 100)
A=np.matrix(A)
x_ = np.zeros([100, 1])
x_[:5, 0] += np.array([i+1 for i in range(5)]) # x_denotes expected x
b = np.matmul(A, x_) + np.random.randn(500, 1) * 0.1 #add a noise to b
lam = 10 # try some different values in {0.1, 1, 10}
def lasso(A,x,b,lam):#lasso的函数值
    f=1/2*np.linalg.norm(np.dot(A,x)-b,ord=2)**2+lam*np.linalg.norm(x,ord=1)
    return f
def b_i(A,x,b,n):
    sum=np.zeros((500,1))
    for i in range(n):
        sum=sum+x[i][0]*A[:,i]
    for i in range(n+1,len(x)):
        sum=sum+x[i][0]*A[:,i]
    b_i=b-sum
    return b_i
def p(f_list,lam,result):
    plt.title('BCD算法迭代图像')
    plt.plot(list(range(len(f_list))), f_list, color='blue', label='lam='+lam)
    plt.legend()
    plt.xlabel('step')
    plt.ylabel('function value')
    plt.show()
    print("最终迭代结果为：",result)
def BCD(A,x,b,lam):
    t=0
    ft=lasso(A,x,b,lam)
    f_list=[ft]
    while t<100:
        t=t+1
        for i in range(len(x)):
            if x[i][0]>0:
                x[i][0]=np.linalg.inv(np.dot(A[:,i].T,A[:,i]))*(np.dot(A[:,i].T,b_i(A,x,b,i))-lam)
            elif x[i][0]<0:
                x[i][0]=np.linalg.inv(np.dot(A[:,i].T,A[:,i]))*(np.dot(A[:,i].T,b_i(A,x,b,i))+lam)
            elif abs(np.dot(A[:,i].T,b_i(A,x,b,i)))<=lam:
                x[i][0]=0
        ft=lasso(A,x,b,lam)
        f_list.append(ft)
    p(f_list,str(lam),lasso(A,x,b,lam))
#BCD(A,x_,b,10)
#BCD(A,x_,b,1)
BCD(A,x_,b,0.1)