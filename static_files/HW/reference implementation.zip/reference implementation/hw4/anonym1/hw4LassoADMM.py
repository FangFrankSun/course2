import numpy as np
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
np.random.seed(2021) # set a constant seed to get same random matrixs
A = np.random.rand(500, 100)
x_ = np.zeros([100, 1])
x_[:5, 0] += np.array([i+1 for i in range(5)]) # x_denotes expected x
b = np.matmul(A, x_) + np.random.randn(500, 1) * 0.1 #add a noise to b
lam = 10 # try some different values in {0.1, 1, 10}
def lasso(A,x,z,b,lam):
    f=1/2*np.linalg.norm(np.dot(A,x)-b,ord=2)**2+lam*np.linalg.norm(z,ord=1)
    return f
def Beta(A):#计算A的最大特征值
    return max(np.linalg.eig(np.dot(A.T,A))[0])
def Soft(z,lam,rho):#软阈值函数
    temp=abs(z).copy()-lam/rho
    for i in range(len(temp)):
        if temp[i]<0:
            temp[i]=0
    Softvalue=np.sign(z)*temp
    return Softvalue
def p(f_list,lam,result):
    plt.title('ADMM算法迭代图像')
    plt.plot(list(range(len(f_list))), f_list, color='blue', label='rou=10,lam='+lam)
    plt.legend()
    plt.xlabel('step')
    plt.ylabel('function value')
    plt.show()
    print("最终迭代结果为：",result)
def ADMM(A,x,b,lam):
    u= np.ones([100, 1])
    rou=10
    z=x.copy()
    t=0
    f_list=[]
    while t<100:
        x=np.dot(np.linalg.inv(np.dot(A.T,A)+rou*np.eye(len(x))),(np.dot(A.T,b)+rou*(z-u)))
        z=Soft(x+u,lam,rou).copy()
        u=u.copy()+x.copy()-z.copy()
        t=t+1
        ft=lasso(A,x,z,b,lam)
        print(ft)
        f_list.append(ft)
    p(f_list,str(lam),lasso(A,x,z,b,lam))
#ADMM(A,x_,b,10)
#ADMM(A,x_,b,1)
ADMM(A,x_,b,0.1)