import numpy as np
import matplotlib.pyplot as plt
class interior_point:
    def __init__(self,A,b,c,mu=1,epsilon=1e-2) -> None:
        self.A=A
        self.b=b
        self.c=c
        self.mu=mu
        self.epsilon=epsilon
        self.lam=np.random.random(self.A.shape[0])
        self.m=np.random.random(self.c.shape[0])
        self.x=np.random.random(self.c.shape[0])
        # self.x=np.array([3,1,0,0])
    #f矩阵
    def F(self):
        return np.concatenate([self.c+self.A.T.dot(self.lam)-self.m,
        self.A.dot(self.x)-self.b,
        np.diag(self.x)@ np.diag(self.m)@ np.ones(self.x.shape)-self.mu*np.ones(self.x.shape)],axis=None)
    #jacobian matrix
    def JacobiF(self):
        return np.block([[np.zeros([self.A.shape[1],self.A.shape[1]]),self.A.T,-np.eye(self.A.shape[1])],
                        [self.A,np.zeros([self.A.shape[0],self.A.shape[0]]),np.zeros(self.A.shape)],
                        [np.diag(self.m),np.zeros(self.A.T.shape),np.diag(self.x)]])
    #迭代方向
    def direction(self):
        return -np.linalg.inv(self.JacobiF())@self.F() 

    def iter(self):
        t=0
        value=[]
        cnt=0

        while np.linalg.norm(self.F()) >= self.epsilon:
            #求迭代方向
            d=self.direction()
            # np.concatenate([self.x,self.lam,self.m],axis=None)
            st=0.2
            # curr_solution=np.linalg.norm(self.F)
            #更新各个参数
            self.x=self.x+st*d[:self.x.shape[0]]
            self.lam=self.lam+st*d[self.x.shape[0]:self.lam.shape[0]+self.x.shape[0]]
            self.m=self.m+st*d[self.lam.shape[0]+self.x.shape[0]:]
            # x不满足可行性，步长过长
            while np.any(self.x<0):
                self.x=self.x-st*d[:self.x.shape[0]]
                self.lam=self.lam-st*d[self.x.shape[0]:self.lam.shape[0]+self.x.shape[0]]
                self.m=self.m-st*d[self.lam.shape[0]+self.x.shape[0]:]
                st*=2
                self.x=self.x+st*d[:self.x.shape[0]]
                self.lam=self.lam+st*d[self.x.shape[0]:self.lam.shape[0]+self.x.shape[0]]
                self.m=self.m+st*d[self.lam.shape[0]+self.x.shape[0]:]
            print(f'{cnt}:最优值：{self.c@self.x}，最优解：{self.x}')
            cnt+=1
            #更新mu
            self.mu=0.1/self.x.shape[0]*self.x@self.m
            value.append(self.c@self.x)
            t+=1
        plt.ylabel('optimal_value')
        plt.xlabel('iter_times')
        plt.plot([i for i in range(t)],value,'*-')
        
        print('最优解：',self.x)
        print('最优值：',self.c@self.x)
        plt.show()


if __name__=='__main__':
    A=np.array([[1,1,1,0],[2,0.5,0,1]])
    b=np.array([5,8])
    c=np.array([-5,-1,0,0])
    intpoint_solver=interior_point(A,b,c)
    intpoint_solver.iter()
