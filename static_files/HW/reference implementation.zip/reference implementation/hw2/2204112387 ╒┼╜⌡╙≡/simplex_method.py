import numpy as np


class simplex_method:
    def __init__(self, x_0, A, c) -> None:
        '''
        x_0:初始基可行解
        A=[B,N]系数矩阵
        Bindex 基变量角标
        Nindex 非基变量角标
        '''
        # 初始基可行解
        self.x = x_0
        # 转化为浮点数
        self.x = self.x.astype('float')
        # 系数矩阵
        self.A = A
        # 目标函数系数
        self.c = c
        # 计算初始基矩阵索引
        self.Bindex = []
        self.Nindex = []
        # self.Bindex=np.where(self.x!=0)[0]#不太严谨
        for col in range(self.A.shape[1]):
            if np.isin(0 and 1, self.A[:, col]):
                self.Bindex.append(col)
            else:
                self.Nindex.append(col)
        self.B = self.A[:, self.Bindex]
        self.N = self.A[:, self.Nindex]
        # 初始非基矩阵索引
        # self.Nindex=np.where(self.x==0)[0]

    def simplex(self):
        # 变量排列顺序
        while True:
            BN = np.concatenate((self.Bindex, self.Nindex), axis=None)
            BinvN = np.linalg.inv(self.B).dot(self.N)
            # 方向dq的矩阵
            Dq = np.concatenate((-BinvN, np.eye(BinvN.shape[0])), axis=0)
            # 计算rq的矩阵
            Rq = self.c[BN].dot(Dq)
            if np.all(Rq >= 0):
                print('最优解：', self.x)
                print('最优值：', self.x.dot(self.c))
                break
            else:
                # 随机选一个rq<0的列
                col = np.where(Rq < 0)[0][0]
                neg = np.where(Dq[:, col] < 0)[0]  # 取dq向量为负的分量
                if np.all(neg):
                    print('无最优值')
                    break
                lambd = min(-(self.x[BN][neg]/Dq[:, col][neg]))  # 非基变量计算检验数
                # ruji=BN[neg][np.argmin(-(self.x[BN][neg]/Dq[:,col][neg]))]
                # 更新x
                #!!发现了错误，self.x应该支持浮点数！！要不然小数部分会被省略！！
                self.x[BN] = self.x[BN] + lambd * Dq[:, col]
                # 更新基变量索引和非基变量索引
                # 这种计算方式是有漏洞的  对于本题来说足够了
                self.Bindex = np.where(self.x != 0)[0]
                self.Nindex = np.where(self.x == 0)[0]
                # 更新B和N
                self.B = self.A[:, self.Bindex]
                self.N = self.A[:, self.Nindex]


if __name__ == '__main__':
    A = np.array([[1, 1, 1, 0], [2, 0.5, 0, 1]])
    x_0 = np.array([0, 0, 5, 8])
    c = np.array([-5, -1, 0, 0])
    simplex_solver = simplex_method(x_0=x_0, A=A, c=c)
    simplex_solver.simplex()
