# from unittest import skip
import numpy as np
import matplotlib.pyplot as plt


class interior_point_qp:
    def __init__(self, A, b, C, d, mu=1, epsilon=0.001) -> None:
        self.A = A
        self.b = b
        self.C = C
        self.d = d
        self.mu = mu
        self.epsilon = epsilon
        self.lam = np.random.random(self.C.shape[0])
        self.m = np.random.random(self.A.shape[0])
        self.x = np.random.random(self.A.shape[0])
        # self.x=np.array([3,1,0,0])
    # f矩阵

    def F(self):
        return np.concatenate([self.C.T@self.lam+2*self.A@self.x+self.b-self.m,
                                self.C@self.x-self.d,
                                np.diag(self.x) @ np.diag(self.m) @ np.ones(self.x.shape)-self.mu*np.ones(self.x.shape)], axis=None)
    # jacobian matrix

    def JacobiF(self):
        return np.block([[2*self.A, self.C.T, -np.eye(self.A.shape[0])],
                        [self.C, np.zeros([self.C.shape[0], self.C.shape[0]]), np.zeros(
                            self.C.shape)],
                        [np.diag(self.m), np.zeros(self.C.T.shape), np.diag(self.x)]])
    # 迭代方向

    def direction(self):
        return -np.linalg.inv(self.JacobiF())@self.F()

    def iter(self):
        t = 0
        value = []
        x1=[]
        x2=[]
        while np.linalg.norm(self.F()) >= self.epsilon:
            # 求迭代方向
            d = self.direction()
            # np.concatenate([self.x,self.lam,self.m],axis=None)

            st = 0.2
            # curr_solution=np.linalg.norm(self.F)
            # 更新各个参数
            self.x = self.x+st*d[:self.x.shape[0]]
            self.lam = self.lam+st*d[self.x.shape[0]
                :self.lam.shape[0]+self.x.shape[0]]
            self.m = self.m+st*d[self.lam.shape[0]+self.x.shape[0]:]
            # x不满足可行性，修改步长
            while np.any(self.x < 0):
                self.x = self.x-st*d[:self.x.shape[0]]
                self.lam = self.lam-st*d[self.x.shape[0]
                    :self.lam.shape[0]+self.x.shape[0]]
                self.m = self.m-st*d[self.lam.shape[0]+self.x.shape[0]:]
                st = np.random.uniform(
                    0, min(abs(self.x[np.where(d[:self.x.shape[0]] < 0)]/d[:self.x.shape[0]][np.where(d[:self.x.shape[0]] < 0)])))
                self.x = self.x+st*d[:self.x.shape[0]]
                self.lam = self.lam+st*d[self.x.shape[0]
                    :self.lam.shape[0]+self.x.shape[0]]
                self.m = self.m+st*d[self.lam.shape[0]+self.x.shape[0]:]
            # 更新mu
            self.mu = 0.1/self.x.shape[0]*self.x@self.m
            value.append(self.x.T@self.A@self.x+self.b.T@self.x)
            x1.append(self.x[0])
            x2.append(self.x[1])
            t += 1
            print('步长：',st,'迭代点：',self.x,"此时的值：",self.x.T@self.A@self.x+self.b.T@self.x)

        plt.figure(dpi=300)

        plt.subplot(1,2,1)
        plt.ylabel('optimal_value')
        plt.xlabel('iter_times')
        plt.plot([i for i in range(t)], value, '*-')
        plt.subplot(1,2,2)
        plt.xlabel('x')
        plt.ylabel('y')
        plt.scatter(x1,x2,color='orange',marker='o')
        plt.plot(x1,x2,c='k')
        print('最优解：', self.x)
        print('最优值：', self.x.T@self.A@self.x+self.b.T@self.x)
        plt.show()


if __name__ == '__main__':
    A = np.block([[np.array([[1, -1], [-1, 2]]), np.zeros([2, 2])],
                 [np.zeros([2, 2]), np.zeros([2, 2])]])
    b = np.array([-2, -6, 0, 0])
    C = np.block([np.array([[0.5, 0.5], [-1, 2]]), np.eye(2)])
    d = np.array([1, 2])
    intpoint_solver = interior_point_qp(A, b, C, d)
    intpoint_solver.iter()
