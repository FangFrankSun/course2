#!/usr/bin/env python
# coding: utf-8

# # 内点法

# In[1]:


import numpy as np
import pandas as pd
import torch


# ## 实现

# In[2]:


class InteriorPoint:

    def __init__(self, v_0, x_0, s_0, mu_0=1):
        self.__x_0 = x_0
        self.__x = self.__x_0
        self.__s_0 = s_0
        self.__s = self.__s_0
        self.__v_0 = v_0
        self.__v = self.__v_0
        self.__mu_0 = mu_0
        self.__mu = self.__mu_0
    
    def __jacobi_F(self, F, num_of_F):
        for i in range(num_of_F):
            if i + 1 == 1:
                grad_ = self.__jacobi(F, i + 1)
            else:
                grad_i = self.__jacobi(F, i + 1)
                grad_ = torch.cat((grad_, grad_i), 0)
        return grad_

    def __jacobi(self, F, num):
        f = F(num, self.__v, self.__x, self.__s, self.__mu)
        for i in range(f.shape[0]):
            f = F(num, self.__v, self.__x, self.__s, self.__mu)
            f.backward(torch.eye(f.shape[0])[i], retain_graph=True)
            if self.__v.grad is None:
                v_grad_ = torch.zeros((len(f), self.__v.shape[0]))
            else:
                v_grad = self.__v.grad.reshape(1, (len(self.__v.grad)))
                if i == 0:
                    v_grad_ = torch.clone(v_grad)
                else:
                    v_grad_ = torch.cat((v_grad_, v_grad), 0)
                self.__v.grad.zero_()
            if self.__x.grad is None:
                x_grad_ = torch.zeros((len(f), self.__x.shape[0]))
            else:
                x_grad = self.__x.grad.reshape(1, (len(self.__x.grad)))
                if i == 0:
                    x_grad_ = torch.clone(x_grad)
                else:
                    x_grad_ = torch.cat((x_grad_, x_grad), 0)
                self.__x.grad.zero_()
            if self.__s.grad is None:
                s_grad_ = torch.zeros((len(f), self.__s.shape[0]))
            else:
                s_grad = self.__s.grad.reshape(1, (len(self.__s.grad)))
                if i == 0:
                    s_grad_ = torch.clone(s_grad)
                else:
                    s_grad_ = torch.cat((s_grad_, s_grad), 0)
                self.__s.grad.zero_()
        grad_ = torch.cat((v_grad_, x_grad_, s_grad_), 1)
        return grad_

    def __update_mu(self):
        self.__mu = 0.1 / len(self.__s) * (self.__s.T@self.__x)

    def __update_vxs(self, F, num_of_F):
        grad = self.__jacobi_F(F, num_of_F)
        grad_inv = grad.inverse()
        F_mu = self.__get_F(F, num_of_F, self.__v, self.__x, self.__s)
        delta = grad_inv@(-F_mu)
        delta_v = delta[:self.__v.shape[0]].reshape((1,-1))[0]
        delta_x = delta[self.__v.shape[0]:self.__v.shape[0] + self.__x.shape[0]].reshape((1,-1))[0]
        delta_s = delta[-self.__s.shape[0]:].reshape((1,-1))[0]
        step = self.__line_search_step(F, num_of_F, delta_v, delta_x, delta_s)
        self.__v = torch.from_numpy(self.__v.detach().numpy() + step * delta_v.detach().numpy())
        self.__x = torch.from_numpy(self.__x.detach().numpy() + step * delta_x.detach().numpy())
        self.__s = torch.from_numpy(self.__s.detach().numpy() + step * delta_s.detach().numpy())
        self.__v.requires_grad_(True)
        self.__x.requires_grad_(True)
        self.__s.requires_grad_(True)

    def __line_search_step(self, F, num_of_F, delta_v, delta_x, delta_s, beta=0.8):
        step = 1
        while True:
            if all(self.__s+step*delta_s>=0) and torch.norm(self.__get_F(F, num_of_F, self.__v+step*delta_v, self.__x+step*delta_x, self.__s+step*delta_s)) <= 0.99*torch.norm(self.__get_F(F, num_of_F, self.__v, self.__x, self.__s)):
                break
            else:
                step = beta * step
        print(step)
        return step
    
    def __get_F(self, F, num_of_F, v, x, s):
        for i in range(num_of_F):
            if i == 0:
                F_mu = F(i + 1, v, x, s, self.__mu)
            else:
                F_mu_i = F(i + 1, v, x, s, self.__mu)
                F_mu = torch.cat((F_mu, F_mu_i))
        return F_mu

    def solve(self, F, num_of_F, epsilon):
        try:
            zz = torch.norm(self.__get_F(F, num_of_F, self.__v, self.__x, self.__s)).detach().numpy()
            while zz >= epsilon:
                self.__update_vxs(F, num_of_F)
                self.__update_mu()
                zz = torch.norm(self.__get_F(F, num_of_F, self.__v, self.__x, self.__s)).detach().numpy()
        except Exception as e:
            print(e.args[0])
    
    def get_x(self):
        return self.__x.detach().numpy()


# ## HW4(3)

# In[3]:


def F_mu(i, v, x, s, mu):
    X = torch.diag(x)
    S = torch.diag(s)
    e = torch.ones(S.shape[0])
    if i == 1:
        return A.T@v+c-s
    elif i == 2:
        return A@x-b
    elif i == 3:
        return S@X@e-mu*e


# In[4]:


v = torch.tensor([1., 1.], requires_grad=True)
x = torch.tensor([1., 2., 2., 5.], requires_grad=True)
s = torch.tensor([1., 1/2, 1/2., 1/5.], requires_grad=True)
c = torch.tensor([-5., -1., 0, 0])
A = torch.tensor([[1, 1, 1, 0], [2, 1/2, 0, 1]])
b = torch.tensor([5, 8])


# In[5]:


i_p = InteriorPoint(v, x, s)


# In[6]:


i_p.solve(F_mu, 3, 0.00001)


# In[7]:


x_star = i_p.get_x()
print(x_star)

