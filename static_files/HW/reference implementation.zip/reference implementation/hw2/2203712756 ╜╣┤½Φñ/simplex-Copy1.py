#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd


# # 单纯形法

# In[2]:


class Simplex():

    def __init__(self, x_0, c, matrix):
        self.__x_0 = x_0
        self.__x_star = self.__x_0
        self.__c = c
        self.__matrix = matrix

    def get_x_0(self):
        return self.__x_0

    def get_x_star(self):
        return self.__x_star

    def get_optimal_value(self):
        return np.dot(self.__x_star, self.__c)

    def __get_basis_matrix(self, basis_index, non_basis_index):
        basis_matrix = self.__matrix[:, basis_index]
        non_basis_matrix = self.__matrix[:, non_basis_index]
        return basis_matrix, non_basis_matrix

    def __update(self, x_lambda, d):
        self.__x_star = self.__x_star + x_lambda * d

    def __get_non_matrix(self, basis_matrix, non_basis_matrix, basis_index, non_basis_index):
        basis_inv = np.linalg.inv(basis_matrix)
        b_inv_n = -np.dot(basis_inv,  non_basis_matrix)
        e = np.eye(non_basis_matrix.shape[1])
        non_matrix = np.vstack((b_inv_n, e))
        non_matrix_0 = non_matrix.copy()
        for i in range(len(basis_index)):
            non_matrix_0[basis_index[i]] = non_matrix[i]
        for i in range(len(non_basis_index)):
            non_matrix_0[non_basis_index[i]] = non_matrix[i + len(basis_matrix)]
        return non_matrix_0

    def __get_d(self, non_matrix, non_basis_index):
        for i in range(len(non_basis_index)):
            d = non_matrix[:, i]
            d = d.reshape(1, -1).A[0]
            cost = self.__reduce_cost(d)
            if cost < 0 and not(all(d >= 0)):
                return d
            elif cost < 0 and all(d >= 0):
                raise Exception('The LP is unbounded below.')
        return None

    def __get_lambda(self, d):
        position = np.where(d < 0)
        x = self.__x_star[position]
        d = d[position]
        x_lambda = min(-x/d)
        return x_lambda

    def __reduce_cost(self, d):
        cost = np.dot(self.__c, d)
        return cost

    def __get_basis_index(self):
        basis_index = []
        non_basis_index = []
        number = self.__matrix.shape[0]
        for i in range(len(self.__x_star)):
            if self.__x_star[i] != 0:
                basis_index.append(i)
            else:
                non_basis_index.append(i)
        length = len(basis_index)
        for i in range(number - length):
            basis_index.append(non_basis_index.pop())
        return basis_index, non_basis_index

    def solve(self):
        try:
            while True:
                basis_index, non_basis_index = self.__get_basis_index()
                basis_m, non_basis_m = self.__get_basis_matrix(basis_index, non_basis_index)
                non_matrix = self.__get_non_matrix(basis_m, non_basis_m, basis_index, non_basis_index)
                d = self.__get_d(non_matrix, non_basis_index)
                if d is None:
                    break
                x_lambda = self.__get_lambda(d)
                self.__update(x_lambda, d)
        except Exception as e:
            print(e.args[0])


# # HW4(2)

# In[3]:


x_0_42 = np.array([0, 0, 5, 8])
c_42 = np.array([-5, -1, 0, 0])
matrix_42 = np.matrix([[1, 1, 1, 0], [2, 1/2, 0, 1]])
simplex_42 = Simplex(x_0_42, c_42, matrix_42)
simplex_42.solve()
print(simplex_42.get_x_star())
print(simplex_42.get_optimal_value())

