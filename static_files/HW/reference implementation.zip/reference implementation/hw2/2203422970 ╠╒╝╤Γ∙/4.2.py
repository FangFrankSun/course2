#!/usr/bin/env python
# coding: utf-8

# In[1]:


from scipy import optimize
import numpy as np

c = np.array([[-5, -1]])
a = np.array([[1, 1], [2, 0.5]])
b = np.array([[5], [8]])
res = optimize.linprog(c, a, b)
print(res.x) # 最优解
print(res.fun) # 目标函数极小值


# In[ ]:




